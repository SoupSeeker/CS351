import re

#In this HW, we will use regular expression to cut 1 line of code
# into tokens and print the tokens out with <type, token> format.

#My general strategy is going to be to make a tokenList that has token tuples with [type, token]
#and return that tokenList, which we can pop tokens off of to manage easily

#ran into strange issue when trying to use \b, because '\b' in ASCII is a backspace, so we need r'\b' to ensure
#it is interpreted as '\b' - used stackoverflow article to help figure out this
def tokenize(input):
    tokenList = []

    keywords = re.compile('\W*if|float|else|int\W*')
    identifiers = re.compile(r'\b(?!if|else|int|float|[0-9]+\b)\w+')
    operators = re.compile('\W*\+|\*|>|=\W*')
    separators = re.compile('\(|\)|\"|:|;')
    intLiterals = re.compile(r'(?<!\.)\b[0-9]+\b(?!\.)')   #had to search up how to use the negative lookbehind, need to ensure there is no . before or after the [0-9]+
    floatLiterals = re.compile('\d+\.\d+')
    stringLiterals = re.compile('[\"|\'][A-Za-z]+[\"|\']')

    keyResult = keywords.search(input)
    identResult = identifiers.search(input)
    opResult = operators.findall(input)     #using findall in operators, seperators, int, float, and strings
    sepResult = separators.findall(input)
    intResult = intLiterals.findall(input)
    floatResult = floatLiterals.findall(input)
    stringResult = stringLiterals.findall(input)

    if keyResult != []:
        tokenList.append([f"<Keyword, {keyResult.group(0)}>"])
    if sepResult != []:
        for x in sepResult:
            tokenList.append([f"<Separator, {x}>"])
    if identResult != []:
        tokenList.append([f"<Identifier, {identResult.group(0)}>"])
    if opResult != []:
        for x in opResult:
            tokenList.append([f"<Operator, {x}>"])
    if floatResult != []:
        for x in floatResult:
            tokenList.append([f"<Float, {x}>"])
    if intResult != []:
        for x in intResult:
            tokenList.append([f"<Int, {x}>"])
    if stringResult != []:
        tokenList.append([f"<String, {stringResult}>"])


    for x in tokenList:
        print("".join(x))

    return tokenList

if __name__ == '__main__':
    test1input = "int A1=15"
    test2input = "float A2 = 3.14"
    test3input = "if (A1 > 10)"
    print("TEST 1")
    tokenize(test1input)
    print("TEST 2")
    tokenize(test2input)
    print("TEST 3")
    tokenize(test3input)

